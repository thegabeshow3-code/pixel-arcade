(() => {
 const games = window.PIXEL_ARCADE_GAMES || [];
 const grid = document.getElementById("gameGrid");
 const search = document.getElementById("gameSearch");
 const resultCount = document.getElementById("resultCount");
 const gameCount = document.getElementById("gameCount");
 const empty = document.getElementById("emptyState");
 let category = "All";
 let query = "";
 let favorites = new Set();
 try { favorites = new Set(JSON.parse(localStorage.getItem("pixelArcadeFavorites") || "[]")); } catch {}
 gameCount.textContent = games.length;
 document.querySelector('[data-category="All"] span').textContent = games.length;

 function render() {
   const shown = games.filter(g => (category === "All" || g.category === category) &&
     (g.name + " " + g.category + " " + g.description + " " + g.tag).toLowerCase().includes(query.toLowerCase()));
   resultCount.textContent = shown.length;
   grid.innerHTML = shown.map((g, i) => `
     <article class="game-card">
       <div class="game-art" style="--artbg:${g.bg};--glow:${g.glow}">
         <span class="art-label">${g.tag}</span><span class="glyph" aria-hidden="true">${g.glyph}</span><span class="art-index">${String(games.indexOf(g)+1).padStart(2,"0")}</span>
       </div>
       <div class="game-info"><div class="game-info-top"><h3>${escapeHtml(g.name)}</h3><span class="genre">${escapeHtml(g.category.toUpperCase())}</span></div>
       <p>${escapeHtml(g.description)}</p><div class="game-actions"><a class="play-link" href="${g.url}" target="_blank" rel="noopener noreferrer">OPEN GAME <span>↗</span></a>
       <button class="favorite ${favorites.has(g.id) ? "saved" : ""}" type="button" data-favorite="${g.id}" aria-label="${favorites.has(g.id) ? "Remove" : "Add"} ${escapeHtml(g.name)} ${favorites.has(g.id) ? "from" : "to"} favorites" title="Save favorite">${favorites.has(g.id) ? "♥" : "♡"}</button></div></div>
     </article>`).join("");
   empty.hidden = shown.length !== 0;
   grid.hidden = shown.length === 0;
 }
 function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
 document.querySelectorAll(".filter").forEach(btn => btn.addEventListener("click", () => {
   category = btn.dataset.category;
   document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b === btn));
   render();
 }));
 search.addEventListener("input", () => { query = search.value.trim(); render(); });
 document.getElementById("clearSearch").addEventListener("click", () => { search.value = ""; query = ""; render(); search.focus(); });
 document.getElementById("resetFilters").addEventListener("click", () => {
   category = "All"; query = ""; search.value = "";
   document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b.dataset.category === "All"));
   render();
 });
 grid.addEventListener("click", e => {
   const btn = e.target.closest("[data-favorite]"); if (!btn) return;
   const id = btn.dataset.favorite;
   if (favorites.has(id)) favorites.delete(id); else favorites.add(id);
   try { localStorage.setItem("pixelArcadeFavorites", JSON.stringify([...favorites])); } catch {}
   render();
 });
 document.getElementById("webSearchForm").addEventListener("submit", e => {
   e.preventDefault();
   const q = document.getElementById("webQuery").value.trim(); if (!q) return;
   const engine = document.querySelector('input[name="engine"]:checked').value;
   const urls = {duck:"https://duckduckgo.com/?q=",google:"https://www.google.com/search?q=",bing:"https://www.bing.com/search?q="};
   window.open(urls[engine] + encodeURIComponent(q), "_blank", "noopener,noreferrer");
 });
 document.getElementById("themeToggle").addEventListener("click", () => document.body.classList.toggle("high-contrast"));
 document.addEventListener("keydown", e => {
   if (e.key === "/" && !["INPUT","TEXTAREA"].includes(document.activeElement.tagName)) { e.preventDefault(); search.focus(); }
   if (e.key === "Escape" && document.activeElement === search) { search.value = ""; query = ""; render(); search.blur(); }
 });
 render();
})();