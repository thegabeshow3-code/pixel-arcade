# Pixel Arcade

A responsive, static game discovery site with a black-and-red arcade look.

## Features
- 12 game discovery cards across arcade, puzzle, action, racing, and strategy
- Live text search and category filters
- Favorite buttons saved in the browser with localStorage
- Separate web search for DuckDuckGo, Google, or Bing
- Responsive desktop and mobile layout
- No server, build step, API key, or install required

## Run locally
Open `index.html` in a modern browser. For best results, use a simple local web server or the hosting preview.

## Publish with GitHub Pages
1. Sign in at https://github.com/ and create a new public repository named `pixel-arcade`.
2. Upload `index.html`, `styles.css`, `games.js`, `app.js`, and this README to the repository root.
3. Open **Settings → Pages**.
4. Under build and deployment, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
5. Wait for the Pages build. The site URL will be shown in the Pages settings and usually follows `https://YOUR-USERNAME.github.io/pixel-arcade/`.

## Alternative: Cloudflare Pages
Create a Pages project, upload the site files using the dashboard's direct-upload flow, and use the generated `*.pages.dev` address.

## Editing games
Edit `games.js`. Each game has a name, category, short description, visual colors, and a destination URL. The links are launch links to game portals, not embedded games; external sites may change, require cookies, or be blocked by a network. Replace them with direct game URLs you have permission to use if you want specific titles.

## Important
This site does not bypass school filters or device restrictions. A hosting URL can still be blocked by a school network. Follow your school's acceptable-use rules.
