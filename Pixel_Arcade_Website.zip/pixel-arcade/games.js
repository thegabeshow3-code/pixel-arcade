window.PIXEL_ARCADE_GAMES = [
 {id:"neon-dash",name:"Neon Dash",category:"Arcade",glyph:"⚡",tag:"QUICK PLAY",bg:"#261018",glow:"#ff343d",description:"Dodge hazards and chase a new high score.",url:"https://poki.com/"},
 {id:"mind-maze",name:"Mind Maze",category:"Puzzle",glyph:"▦",tag:"BRAIN MODE",bg:"#161b2a",glow:"#8c9dff",description:"Warm up your brain with clever puzzles.",url:"https://www.coolmathgames.com/"},
 {id:"pixel-racer",name:"Pixel Racer",category:"Racing",glyph:"🏎",tag:"FULL SPEED",bg:"#261712",glow:"#ff724b",description:"Hit the track and race for the top spot.",url:"https://poki.com/"},
 {id:"tower-tactics",name:"Tower Tactics",category:"Strategy",glyph:"♜",tag:"PLAN AHEAD",bg:"#21172b",glow:"#c07cff",description:"Think ahead, build a plan, and outsmart the board.",url:"https://www.crazygames.com/"},
 {id:"orbit-breaker",name:"Orbit Breaker",category:"Arcade",glyph:"◉",tag:"ARCADE CLASSIC",bg:"#111f2b",glow:"#43d9ff",description:"Keep moving and see how long you can last.",url:"https://poki.com/"},
 {id:"shadow-strike",name:"Shadow Strike",category:"Action",glyph:"✦",tag:"ACTION",bg:"#211018",glow:"#ff343d",description:"Jump into fast action and test your reflexes.",url:"https://www.crazygames.com/"},
 {id:"block-by-block",name:"Block by Block",category:"Puzzle",glyph:"▧",tag:"PUZZLE TIME",bg:"#18251e",glow:"#74e7a3",description:"Fit the pieces together and clear the board.",url:"https://www.coolmathgames.com/"},
 {id:"drift-city",name:"Drift City",category:"Racing",glyph:"➤",tag:"DRIFT ZONE",bg:"#282016",glow:"#ffc45c",description:"Find your line and leave the competition behind.",url:"https://poki.com/"},
 {id:"boss-rush",name:"Boss Rush",category:"Action",glyph:"☠",tag:"BOSS FIGHT",bg:"#2a1016",glow:"#ff4859",description:"Take on tough challenges and keep your cool.",url:"https://www.crazygames.com/"},
 {id:"chess-club",name:"Chess Club",category:"Strategy",glyph:"♞",tag:"THINK FIRST",bg:"#17211e",glow:"#b2e5a6",description:"Sharpen your strategy one move at a time.",url:"https://www.chess.com/play"},
 {id:"tiny-golf",name:"Tiny Golf",category:"Arcade",glyph:"⛳",tag:"TAKE A SHOT",bg:"#17251a",glow:"#9bea79",description:"Line up the shot and aim for a hole in one.",url:"https://poki.com/"},
 {id:"word-wizard",name:"Word Wizard",category:"Puzzle",glyph:"Aa",tag:"WORD PLAY",bg:"#22182b",glow:"#dc8cff",description:"Play with words, clues, and quick thinking.",url:"https://www.coolmathgames.com/"}
];